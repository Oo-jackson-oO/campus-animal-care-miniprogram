Page({
  data: {
    notices: [
      "图书馆附近发现受伤小猫，需要志愿者协助送医",
      "本周文创义卖收益将用于流浪动物疫苗",
      "欢迎分享你和校园毛孩子的故事"
    ],
    products: [
      { id: 1, name: "猫咪帆布包", price: "39.9", image: "/images/bag.jpg" },
      { id: 2, name: "爱心徽章套装", price: "9.9", image: "/images/badge.jpg" }
    ],
    animals: [
      { id: 1, name: "小橘", gender: "公", sterilized: false, image: "/images/cat1.jpg" },
      { id: 2, name: "雪球", gender: "母", sterilized: true, image: "/images/cat2.jpg" }
    ]
  }
});